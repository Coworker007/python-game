from PyQt5.QtWidgets import QFrame, QMenuBar, QAction, QMessageBox
from PyQt5.QtCore import Qt, QBasicTimer, pyqtSignal, pyqtSlot, QPoint
from PyQt5.QtGui import QPainter, QPen, QBrush, QColor
from piece import Piece

class Board(QFrame):  # base the board on a QFrame widget
    updateTimerSignal = pyqtSignal(int) # signal sent when timer is updated
    clickLocationSignal = pyqtSignal(str, int) # signal sent when there is a new click location

    # TODO set the board width and height to be square
    boardWidth  = 7     # board is 0 squares wide # TODO this needs updating
    boardHeight = 7     #
    timerSpeed  = 1000     # the timer updates ever 1 second
    counter     = 120    # the number the counter will count down from (2 minutes)

    def __init__(self, parent):
        super().__init__(parent)
        self.initBoard()
        self.player = 1     # 1 is black, 0 is white
        self.painter = None # Painter to paint the pieces later

        mainMenu = QMenuBar(self) # create and a menu bar
        helpMenu = mainMenu.addMenu(" Help")

        helpAction = QAction("Rules", self)
        helpAction.setShortcut("Ctrl+H")
        helpMenu.addAction(helpAction)
        helpAction.triggered.connect(self.help)        

    def initBoard(self):
        '''initiates board'''
        self.timer = QBasicTimer()  # create a timer for the game
        self.isStarted = False      # game is not currently started
        self.start()                # start the game which will start the timer

        self.boardArray =[]         # TODO - create a 2d int/Piece array to store the state of the game
        for w in range(self.boardWidth):
            row = []
            for h in range(self.boardHeight):
                 row.append(Piece().NoPiece)
            self.boardArray.append(row)

        self.printBoardArray()    # TODO - uncomment this method after create the array above

    def printBoardArray(self):
        '''prints the boardArray in an attractive way'''
        print("boardArray:")
        print('\n'.join(['\t'.join([str(cell) for cell in row]) for row in self.boardArray]))

    def mousePosToColRow(self, event):
        '''convert the mouse click event to a row and column'''
        clickLoc = [int(event.x()), int(event.y())]
        # Calculate the row and column 
        y = int(clickLoc[0] / self.squareWidth())
        x = int(clickLoc[1] / self.squareHeight())
        return x, y

    def squareWidth(self):
        '''returns the width of one square in the board'''
        return self.contentsRect().width() / self.boardWidth

    def squareHeight(self):
        '''returns the height of one square of the board'''
        return self.contentsRect().height() / self.boardHeight

    def start(self):
        '''starts game'''
        self.isStarted = True                       # set the boolean which determines if the game has started to TRUE
        self.resetGame()                            # reset the game
        self.timer.start(self.timerSpeed, self)     # start the timer with the correct speed
        print("start () - timer is started")

    def timerEvent(self, event):
        '''this event is automatically called when the timer is updated. based on the timerSpeed variable '''
        # TODO adapter this code to handle your timers
        if event.timerId() == self.timer.timerId():  # if the timer that has 'ticked' is the one in this class
            if Board.counter == 0:
                print("Game over")
            self.counter -= 1
            #print('timerEvent()', self.counter)
            self.updateTimerSignal.emit(self.counter)
        else:
            super(Board, self).timerEvent(event)      # if we do not handle an event we should pass it to the super
                                                        # class for handelingother wise pass it to the super class for handling

    def paintEvent(self, event):
        '''paints the board and the pieces of the game'''
        painter = QPainter(self)
        self.drawBoardSquares(painter)
        self.drawPieces(painter)

    def mousePressEvent(self, event):
        '''this event is automatically called when the mouse is pressed'''
        clickLoc = "click location ["+str(event.x())+","+str(event.y())+"]"     # the location where a mouse click was registered
        print("mousePressEvent() - "+clickLoc)
        # TODO you could call some game logic here
        x, y = self.mousePosToColRow(event)
          
        # Draw piece at this position
        if self.boardArray[x][y] == Piece().NoPiece:
            self.counter = 121 # Reset the timer
            # Make sure there is no piece already on this spot
            if self.player:
                self.player = not self.player       # Switch the player
                self.boardArray[x][y] = Piece().Black
            else:
                self.player = not self.player
                self.boardArray[x][y] = Piece().White

        self.clickLocationSignal.emit(clickLoc, self.player)

    def resetGame(self):
        '''clears pieces from the board'''
        # TODO write code to reset game
        # Empty the board
        self.boardArray = []
        for w in range(self.boardWidth):
            row = []
            for h in range(self.boardHeight):
                 row.append(Piece().NoPiece)
            self.boardArray.append(row)

    def tryMove(self, newX, newY):
        '''tries to move a piece'''

    def drawBoardSquares(self, painter):
        '''draw all the square on the board'''
        # TODO set the default colour of the brush
        painter.setPen(QPen(Qt.black, 8, Qt.SolidLine))
        brush_color = QBrush(QColor(210,105,30))
        for row in range(0, Board.boardHeight):
            for col in range (0, Board.boardWidth):
                painter.save()
                colTransformation = self.squareWidth()* col # TODO set this value equal the transformation in the column direction
                rowTransformation = self.squareHeight() * row # TODO set this value equal the transformation in the row direction
                painter.translate(colTransformation,rowTransformation)
                painter.fillRect(0, 0, self.squareWidth(), self.squareHeight(), brush_color)                          # TODO provide the required arguments
                painter.restore()
                # TODO change the colour of the brush so that a checkered board is drawn
                if brush_color == QColor(210,105,30):
                    brush_color = QColor(245,222,179)
                else:
                    brush_color = QColor(210,105,30)

    def drawPieces(self, painter):
        '''draw the prices on the board'''
        colour = Qt.transparent # empty square could be modeled with transparent pieces
        for row in range(0, len(self.boardArray)):
            for col in range(0, len(self.boardArray[0])):
                painter.save()
                colTransformation = self.squareWidth()* col # TODO set this value equal the transformation in the column direction
                rowTransformation = self.squareHeight() * row # TODO set this value equal the transformation in the row direction
                painter.translate(colTransformation,rowTransformation)
                # TODO draw some the pieces as ellipses
                # TODO choose your colour and set the painter brush to the correct colour
                radius = (self.squareWidth() - 2) / 2
                center = QPoint(radius, radius)
                if self.boardArray[row][col] == Piece().NoPiece:
                    painter.setPen(QPen(colour, 8, Qt.SolidLine))
                    painter.setBrush(QBrush(colour))
                elif self.boardArray[row][col] == Piece().Black:
                    painter.setPen(QPen(Qt.black, 8, Qt.SolidLine))
                    painter.setBrush(QBrush(Qt.black))
                else:
                    painter.setPen(QPen(Qt.white, 8, Qt.SolidLine))
                    painter.setBrush(QBrush(Qt.white))
                painter.drawEllipse(center, radius, radius)
                painter.restore()

    def help(self):
        msgBox = QMessageBox()
        msgBox.setWindowTitle("Rules")
        msgBox.setText("""The rules
A game of Go starts with an empty board. Each player has an effectively unlimited supply of pieces (called stones), one taking the black stones, the other taking white. The main object of the game is to use your stones to form territories by surrounding vacant areas of the board. It is also possible to capture your opponent's stones by completely surrounding them.

Players take turns, placing one of their stones on a vacant point at each turn, with Black playing first. Note that stones are placed on the intersections of the lines rather than in the squares and once played stones are not moved. However they may be captured, in which case they are removed from the board, and kept by the capturing player as prisoners.

At the end of the game, the players count one point for each vacant point inside their own territory, and one point for every stone they have captured. The player with the larger total of territory plus prisoners is the winner.""")
        msgBox.exec_()

    def make_connection(self, par):
        par.playerPass.connect(self.player_pass)
        par.resetSignal.connect(self.resetGame)

    @pyqtSlot(int)
    def player_pass(self, player):
        self.player = player