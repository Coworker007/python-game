from PyQt5.QtWidgets import QDockWidget, QVBoxLayout, QWidget, QLabel, QPushButton #TODO import additional Widget classes as desired
from PyQt5.QtCore import pyqtSlot, pyqtSignal

class ScoreBoard(QDockWidget):
    '''# base the score_board on a QDockWidget'''

    playerPass = pyqtSignal(int)
    resetSignal = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.initUI()
        self.player = None

    def initUI(self):
        '''initiates ScoreBoard UI'''
        self.resize(200, 200)
        self.center()
        self.setWindowTitle('ScoreBoard')
        #create a widget to hold other widgets
        self.mainWidget = QWidget()
        self.mainLayout = QVBoxLayout()

        #create two labels which will be updated by signals
        self.label_clickLocation = QLabel("Click Location: ")
        self.label_timeRemaining = QLabel("Time remaining: ")
        self.mainWidget.setLayout(self.mainLayout)
        self.mainLayout.addWidget(self.label_clickLocation)
        self.mainLayout.addWidget(self.label_timeRemaining)

        # Create a third label to show the current player
        self.label_player = QLabel("Current Player: Black")
        self.mainLayout.addWidget(self.label_player)

        # Create label for prisoners and territory
        self.label_prisoners = QLabel("Black prisoners: 0\nWhite prisoners: 0")
        self.label_territory = QLabel("Black territory captured: 0\nWhite territory captured: 0")
        self.mainLayout.addWidget(self.label_prisoners)
        self.mainLayout.addWidget(self.label_territory)

        # Add buttons for player pass and reset
        self.btn_pass = QPushButton("Pass")
        self.btn_reset = QPushButton("Reset")
        self.btn_pass.clicked.connect(self.player_pass)
        self.btn_reset.clicked.connect(self.reset)
        self.mainLayout.addWidget(self.btn_pass)
        self.mainLayout.addWidget(self.btn_reset)
        self.setWidget(self.mainWidget)
        self.show()

    def center(self):
        '''centers the window on the screen, you do not need to implement this method'''

    def make_connection(self, board):
        '''this handles a signal sent from the board class'''
        # when the clickLocationSignal is emitted in board the setClickLocation slot receives it
        board.clickLocationSignal.connect(self.setClickLocation)
        # when the updateTimerSignal is emitted in the board the setTimeRemaining slot receives it
        board.updateTimerSignal.connect(self.setTimeRemaining)

    @pyqtSlot(str, int) # checks to make sure that the following slot is receiving an argument of the type 'int'
    def setClickLocation(self, clickLoc, player):
        '''updates the label to show the click location'''
        self.label_clickLocation.setText("Click Location:" + clickLoc)
        print('slot ' + clickLoc)
        # Update the third label
        self.player = player
        if player:
            self.label_player.setText("Current player: Black")
        else:
            self.label_player.setText("Current player: White")

    @pyqtSlot(int)
    def setTimeRemaining(self, timeRemainng):
        '''updates the time remaining label to show the time remaining'''
        update = "Time Remaining:" + str(timeRemainng)
        self.label_timeRemaining.setText(update)
        #print('slot '+update)
        # self.redraw()

    def updatePrisoners(self, bp, wp):
        '''updates the prisoners label. Takes as input the current black prisoners and white prisoners'''
        prisoners = "Black prisoners: " + str(bp) + "\nWhite prisoners: " + str(wp)
        self.label_prisoners.setText(prisoners)

    def updateTerritory(self, bt, wt):
        '''updates the territory label. Takes as input the current black territory and white territory'''
        territory = "Black territory captured: " + str(bt) + "\nWhite territory captured: " + str(wt)
        self.label_territory.setText(territory)

    def player_pass(self):
        '''let's the current player pass. updates current player'''
        self.player = not self.player
        self.playerPass.emit(self.player)
        # Update the third label
        if self.player:
            self.label_player.setText("Current player: Black")
        else:
            self.label_player.setText("Current player: White")

    def reset(self):
        self.resetSignal.emit()